import 'tailwindcss/tailwind.css'
import '../style/master.css'

const App = ({ Component, pageProps }) => <Component {...pageProps} />

export default App
