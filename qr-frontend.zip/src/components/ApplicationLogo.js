const ApplicationLogo = () => <img src="/img/logo.png" alt="" />

export default ApplicationLogo
